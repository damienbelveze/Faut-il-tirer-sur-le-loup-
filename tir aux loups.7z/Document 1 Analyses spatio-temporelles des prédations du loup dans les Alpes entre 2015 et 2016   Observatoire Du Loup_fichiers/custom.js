jQuery(document).ready(function($) {

    $(".finewp-nav-secondary .finewp-secondary-nav-menu").addClass("finewp-secondary-responsive-menu").before('<div class="finewp-secondary-responsive-menu-icon"></div>');

    $(".finewp-secondary-responsive-menu-icon").click(function(){
        $(this).next(".finewp-nav-secondary .finewp-secondary-nav-menu").slideToggle();
    });

    $(window).resize(function(){
        if(window.innerWidth > 1112) {
            $(".finewp-nav-secondary .finewp-secondary-nav-menu, nav .sub-menu, nav .children").removeAttr("style");
            $(".finewp-secondary-responsive-menu > li").removeClass("finewp-secondary-menu-open");
        }
    });

    $(".finewp-secondary-responsive-menu > li").click(function(event){
        if (event.target !== this)
        return;
        $(this).find(".sub-menu:first").slideToggle(function() {
            $(this).parent().toggleClass("finewp-secondary-menu-open");
        });
        $(this).find(".children:first").slideToggle(function() {
            $(this).parent().toggleClass("finewp-secondary-menu-open");
        });
    });

    $("div.finewp-secondary-responsive-menu > ul > li").click(function(event) {
        if (event.target !== this)
            return;
        $(this).find("ul:first").slideToggle(function() {
            $(this).parent().toggleClass("finewp-secondary-menu-open");
        });
    });

    if(finewp_ajax_object.sticky_menu){
    // grab the initial top offset of the navigation 
    var finewpstickyNavTop = $('.finewp-primary-menu-container').offset().top;
    
    // our function that decides weather the navigation bar should have "fixed" css position or not.
    var finewpstickyNav = function(){
        var finewpscrollTop = $(window).scrollTop(); // our current vertical position from the top
             
        // if we've scrolled more than the navigation, change its position to fixed to stick to top,
        // otherwise change it back to relative
        if(finewp_ajax_object.sticky_menu_mobile){
            if (finewpscrollTop > finewpstickyNavTop) {
                $('.finewp-primary-menu-container').addClass('finewp-fixed');
            } else {
                $('.finewp-primary-menu-container').removeClass('finewp-fixed'); 
            }
        } else {
                if(window.innerWidth > 1112) {
                    if (finewpscrollTop > finewpstickyNavTop) {
                        $('.finewp-primary-menu-container').addClass('finewp-fixed');
                    } else {
                        $('.finewp-primary-menu-container').removeClass('finewp-fixed'); 
                    }
                }
        }
    };

    finewpstickyNav();
    // and run it again every time you scroll
    $(window).scroll(function() {
        finewpstickyNav();
    });
    }

    $(".finewp-nav-primary .finewp-nav-primary-menu").addClass("finewp-primary-responsive-menu").before('<div class="finewp-primary-responsive-menu-icon"></div>');

    $(".finewp-primary-responsive-menu-icon").click(function(){
        $(this).next(".finewp-nav-primary .finewp-nav-primary-menu").slideToggle();
    });

    $(window).resize(function(){
        if(window.innerWidth > 1112) {
            $(".finewp-nav-primary .finewp-nav-primary-menu, nav .sub-menu, nav .children").removeAttr("style");
            $(".finewp-primary-responsive-menu > li").removeClass("finewp-primary-menu-open");
        }
    });

    $(".finewp-primary-responsive-menu > li").click(function(event){
        if (event.target !== this)
        return;
        $(this).find(".sub-menu:first").slideToggle(function() {
            $(this).parent().toggleClass("finewp-primary-menu-open");
        });
        $(this).find(".children:first").slideToggle(function() {
            $(this).parent().toggleClass("finewp-primary-menu-open");
        });
    });

    $("div.finewp-primary-responsive-menu > ul > li").click(function(event) {
        if (event.target !== this)
            return;
        $(this).find("ul:first").slideToggle(function() {
            $(this).parent().toggleClass("finewp-primary-menu-open");
        });
    });

    $(".finewp-social-icon-search").on('click', function (e) {
        e.preventDefault();
        document.getElementById("finewp-search-overlay-wrap").style.display = "block";
    });

    $(".finewp-search-closebtn").on('click', function (e) {
        e.preventDefault();
        document.getElementById("finewp-search-overlay-wrap").style.display = "none";
    });

    $(".post").fitVids();

    $( 'body' ).prepend( '<div class="finewp-scroll-top"></div>');
    var scrollButtonEl = $( '.finewp-scroll-top' );
    scrollButtonEl.hide();

    $( window ).scroll( function () {
        if ( $( window ).scrollTop() < 20 ) {
            $( '.finewp-scroll-top' ).fadeOut();
        } else {
            $( '.finewp-scroll-top' ).fadeIn();
        }
    } );

    scrollButtonEl.click( function () {
        $( "html, body" ).animate( { scrollTop: 0 }, 300 );
        return false;
    } );

    if ( $().owlCarousel ) {
        var finewpcarouselwrapper = $('.finewp-posts-carousel');
        var imgLoad = imagesLoaded(finewpcarouselwrapper);
        imgLoad.on( 'always', function() {
            finewpcarouselwrapper.each(function(){
                    var $this = $(this);
                    $this.find('.owl-carousel').owlCarousel({
                        autoplay: true,
                        loop: true,
                        margin: 0,
                        smartSpeed: 250,
                        dots: false,
                        nav: true,
                        autoplayTimeout: 4000,
                        autoHeight: false,
                        navText: [ '<i class="fa fa-arrow-left"></i>', '<i class="fa fa-arrow-right"></i>' ],
                        responsive:{
                        0:{
                            items: 1
                        },
                        480:{
                            items: 2
                        },
                        991:{
                            items: 3
                        },
                        1024:{
                            items: 4
                        }
                    }
                });
            });
        });
    } // end if

    if(finewp_ajax_object.sticky_sidebar){
    $('.finewp-main-wrapper, .finewp-sidebar-one-wrapper').theiaStickySidebar({
        containerSelector: ".finewp-content-wrapper",
        additionalMarginTop: 0,
        additionalMarginBottom: 0,
        minWidth: 890,
    });
    }

    // init Masonry
    var $finewp_grid = $('.finewp-posts').masonry({
      itemSelector: '.finewp-grid-post',
      columnWidth: finewp_ajax_object.columnwidth,
      gutter: finewp_ajax_object.gutter,
      percentPosition: true
    });
    // layout Masonry after each image loads
    $finewp_grid.imagesLoaded().progress( function() {
      $finewp_grid.masonry('layout');
    });


    $(".finewp-grid-posts").each(function(){
    var $thisgrid = $(this);

    // init Masonry
    var $finewp_grid_widget = $thisgrid.masonry({
      itemSelector: '.finewp-grid-post',
      columnWidth: $thisgrid.find(".finewp-col-sizer")[0],
      gutter: $thisgrid.find(".finewp-col-gutter")[0],
      percentPosition: true
    });
    // layout Masonry after each image loads
    $finewp_grid_widget.imagesLoaded().progress( function() {
      $finewp_grid_widget.masonry('layout');
    });

    });

});